# =========================================================
# MAPA NORMATIVO – INVERSIÓN PÚBLICA (PERÚ)
# =========================================================

# 1. Definir carpeta de trabajo

setwd("D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA")


# 2. Instalar paquetes (solo la primera vez)
packages <- c("DiagrammeR", "DiagrammeRsvg", "rsvg")
installed <- packages %in% rownames(installed.packages())
if (any(!installed)) install.packages(packages[!installed])

# 3. Cargar paquetes
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# 4. Crear el mapa normativo
grafico_normativo <- grViz("
digraph marco_normativo {
  graph [rankdir = LR, fontsize = 12]
  node  [shape = box, style = rounded, fontsize = 11]
  edge  [fontsize = 10]

  A [label = 'Marco normativo\\nInversión pública (Perú)']

  B [label = 'D. Leg. N° 1252\\nInvierte.pe\\nMEF, 2016']
  C [label = 'D.S. N° 284-2018-EF\\nReglamento Invierte.pe\\nMEF, 2018']
  D [label = 'Instructivo Diagnóstico\\nde Brechas\\nMEF, 2023']
  E [label = 'Ley del Sistema Nacional\\nde Presupuesto Público\\nCongreso, 2004']
  F [label = 'Ley N° 27785\\nSistema Nacional de Control\\nCongreso, 2018']
  G [label = 'D.S. N° 043-2003-PCM\\nLey de Transparencia\\nPresidencia, 2003']

  H [label = 'Cierre de brechas\\n(priorización)']
  I [label = 'Ciclo de inversión pública\\nPMI – F&E – Ejecución – Funcionamiento']
  J [label = 'Recursos y ejecución\\npresupuestal']
  K [label = 'Control y supervisión\\n(obras, plazos, desvíos)']
  L [label = 'Transparencia y\\ndisponibilidad de datos']

  A -> B
  A -> C
  A -> D
  A -> E
  A -> F
  A -> G

  B -> H [label = 'finalidad / principios']
  C -> I [label = 'regula gestión\\nde inversiones']
  D -> H [label = 'define brecha\\ny criterios']
  E -> J [label = 'programación\\ny ejecución']
  F -> K [label = 'control gubernamental']
  G -> L [label = 'acceso a información']

  B -> I [label = 'sistema']
  C -> H [label = 'orientación']
  E -> I [label = 'vinculación\\npresupuestaria']
}
")

# 5. Mostrar el gráfico en RStudio
grafico_normativo

# 6. Exportar a SVG
svg_graph <- export_svg(grafico_normativo)

# 7. Guardar PNG en alta resolución (Word / tesis)
rsvg_png(charToRaw(svg_graph),
         file = "mapa_normativo_inversion_publica.png",
         width = 4000,
         height =
           