############################################################
# ANALISIS ESPACIAL POR AÑO (PANEL -> CORTES ANUALES)
# - Join GeoJSON + Base SFA (Excel)
# - Moran Global (analítico) + Moran MC (999 permutaciones)
# - Moran Scatterplot por año (se guarda .png)
# - LISA por año + mapa de clusters (se guarda .png)
# - Tablas: Moran por año + resumen LISA por año + LISA detallado (CSV)
#
# Directorio de trabajo:
# D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA
############################################################

#-----------------------------------------------------------
# 0) CONFIGURACION INICIAL
#-----------------------------------------------------------
rm(list = ls())

wd <- "D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA"
setwd(wd)
getwd()

# Paquetes (instalar solo la primera vez)
packs <- c("sf","dplyr","readxl","stringi","stringr","spdep","tmap","ggplot2","writexl")
to_install <- packs[!packs %in% installed.packages()[,"Package"]]
if(length(to_install) > 0) install.packages(to_install)

library(sf)
library(dplyr)
library(readxl)
library(stringi)
library(stringr)
library(spdep)
library(tmap)
library(ggplot2)
library(writexl)

#-----------------------------------------------------------
# 0.1) Carpetas de salida
#-----------------------------------------------------------
out_dir <- file.path(wd, "OUTPUT_ESPACIAL_POR_ANIO")
dir.create(out_dir, showWarnings = FALSE)

dir.create(file.path(out_dir, "MAPAS_ET"),   showWarnings = FALSE)
dir.create(file.path(out_dir, "MAPAS_LISA"), showWarnings = FALSE)
dir.create(file.path(out_dir, "SCATTER"),    showWarnings = FALSE)
dir.create(file.path(out_dir, "TABLAS"),     showWarnings = FALSE)
dir.create(file.path(out_dir, "LISA_CSV"),   showWarnings = FALSE)

#-----------------------------------------------------------
# 1) FUNCION DE NORMALIZACION DE REGION
#-----------------------------------------------------------
norm_region <- function(x){
  x %>%
    as.character() %>%
    stringi::stri_trans_general("Latin-ASCII") %>%  # quita tildes
    toupper() %>%
    str_replace_all("\\s+", " ") %>%                # colapsa espacios
    trimws()
}

#-----------------------------------------------------------
# 2) CARGAR MAPA (GeoJSON) Y PREPARAR LLAVE
#-----------------------------------------------------------
map_file <- "peru_departamental_simple.json"
peru_dep <- st_read(map_file, quiet = FALSE)

# Si tu geojson no tiene NOMBDEP, cambia este campo:
geo_region_field <- "NOMBDEP"
if(!(geo_region_field %in% names(peru_dep))){
  stop(paste0("No existe la columna '", geo_region_field, "' en el GeoJSON. Revisa names(peru_dep) y ajusta geo_region_field."))
}

peru_dep <- peru_dep %>%
  mutate(
    Region = norm_region(.data[[geo_region_field]])
  )

#-----------------------------------------------------------
# 3) CARGAR BASE SFA (Excel) Y PREPARAR ET + AÑO
#-----------------------------------------------------------
base_sfa <- read_excel("BASE_SFA_FINAL.xlsx")

# 3.1 Detectar columna de región
# (si ya se llama Region, ok; si no, ajusta aquí)
if(!("Region" %in% names(base_sfa))){
  stop("No encuentro la columna 'Region' en BASE_SFA_FINAL.xlsx. Renombra o ajusta el script para usar tu columna correcta.")
}

# 3.2 Detectar columna de año (Año / Anio / Year)
anio_candidates <- c("Año","Anio","Year","YEAR","anio")
anio_col <- anio_candidates[anio_candidates %in% names(base_sfa)][1]
if(is.na(anio_col)){
  stop("No encuentro columna de año (Año/Anio/Year) en BASE_SFA_FINAL.xlsx. Ajusta el nombre de columna.")
}

# 3.3 Detectar eficiencia técnica: TE_IRIPR (tu variable) -> ET
if(!("TE_IRIPR" %in% names(base_sfa))){
  stop("No se encontró la variable 'TE_IRIPR' en BASE_SFA_FINAL.xlsx.")
}

# 3.4 Limpiar y renombrar
base_sfa <- base_sfa %>%
  mutate(
    Region = norm_region(Region),
    Año = as.integer(.data[[anio_col]]),
    ET = as.numeric(TE_IRIPR)
  ) %>%
  mutate(
    # armonizaciones puntuales (si las necesitas)
    Region = case_when(
      Region %in% c("CUSCO","CUZCO") ~ "CUSCO",
      Region %in% c("LA LIBERTAD","LIBERTAD") ~ "LA LIBERTAD",
      Region %in% c("LIMA","LIMA METROPOLITANA") ~ "LIMA",
      TRUE ~ Region
    )
  )

# Exportar base limpia (opcional)
write_xlsx(base_sfa, file.path(out_dir, "TABLAS", "BASE_SFA_FINAL_LIMPIA.xlsx"))

# Años disponibles
years <- sort(unique(base_sfa$Año))
cat("\nAños detectados:\n"); print(years)

#-----------------------------------------------------------
# 4) OBJETOS PARA GUARDAR RESULTADOS
#-----------------------------------------------------------
moran_tab <- list()
lisa_resumen_tab <- list()

tmap_mode("plot")  # para guardar mapas con tmap_save

#-----------------------------------------------------------
# 5) LOOP POR AÑO: MORAN + SCATTER + LISA + MAPAS
#-----------------------------------------------------------
for (y in years) {
  
  cat("\n==============================\n")
  cat("Procesando año:", y, "\n")
  cat("==============================\n")
  
  # 5.1 ET por región en el año y (si tu Excel ya es 1 obs por región, igual funciona)
  et_y <- base_sfa %>%
    filter(Año == y) %>%
    group_by(Region) %>%
    summarise(ET = mean(ET, na.rm = TRUE), .groups = "drop")
  
  # 5.2 Join con mapa
  map_y <- peru_dep %>%
    left_join(et_y, by = "Region")
  
  # Diagnóstico NA
  na_count <- sum(is.na(map_y$ET))
  if(na_count > 0){
    cat(" - Regiones sin ET tras join (NA):", na_count, "\n")
    # guardo lista para revisar
    write.csv(
      map_y %>% filter(is.na(ET)) %>% st_drop_geometry() %>% select(Region),
      file.path(out_dir, "TABLAS", paste0("REGIONES_SIN_ET_", y, ".csv")),
      row.names = FALSE
    )
  }
  
  # 5.3 Crear objeto limpio (sin NA) para tests
  map_ok <- map_y %>% filter(!is.na(ET))
  
  # Si por algún motivo quedaran muy pocas regiones, saltar
  if(nrow(map_ok) < 10){
    warning(paste0("Año ", y, ": muy pocas regiones con ET (", nrow(map_ok), "). Se omite el análisis."))
    next
  }
  
  # 5.4 Pesos espaciales (Queen)
  nb <- poly2nb(map_ok, queen = TRUE)
  
  # Si hay islas (sin vecinos), se permite con zero.policy=TRUE
  lw <- nb2listw(nb, style = "W", zero.policy = TRUE)
  
  #---------------------------------------------------------
  # 5.A) MORAN GLOBAL (analítico + MC)
  #---------------------------------------------------------
  moran_g <- moran.test(map_ok$ET, lw, zero.policy = TRUE)
  
  set.seed(123)
  moran_mc <- moran.mc(map_ok$ET, lw, nsim = 999, zero.policy = TRUE)
  
  moran_tab[[as.character(y)]] <- data.frame(
    Año = y,
    N = nrow(map_ok),
    Moran_I = as.numeric(moran_g$estimate["Moran I statistic"]),
    Expectation = as.numeric(moran_g$estimate["Expectation"]),
    Variance = as.numeric(moran_g$estimate["Variance"]),
    z_value = as.numeric(moran_g$statistic),
    p_value = as.numeric(moran_g$p.value),
    p_mc = as.numeric(moran_mc$p.value)
  )
  
  #---------------------------------------------------------
  # 5.B) MORAN SCATTERPLOT (guardar PNG)
  #---------------------------------------------------------
  ET_z  <- as.numeric(scale(map_ok$ET))
  ET_lag <- lag.listw(lw, ET_z, zero.policy = TRUE)
  
  scatter_df <- data.frame(ET_z = ET_z, WET_z = ET_lag)
  
  p_scatter <- ggplot(scatter_df, aes(x = ET_z, y = WET_z)) +
    geom_point() +
    geom_hline(yintercept = 0, linetype = 2) +
    geom_vline(xintercept = 0, linetype = 2) +
    geom_smooth(method = "lm", se = FALSE) +
    labs(
      title = paste0("Moran Scatterplot - ET (Año ", y, ")"),
      x = "ET estandarizada (z)",
      y = "Rezago espacial de ET (Wz)"
    ) +
    theme_minimal()
  
  ggsave(
    filename = file.path(out_dir, "SCATTER", paste0("SCATTER_MORAN_ET_", y, ".png")),
    plot = p_scatter, width = 8, height = 6, dpi = 300
  )
  
  #---------------------------------------------------------
  # 5.C) LISA (Moran Local) + CLUSTERS + MAPA
  #---------------------------------------------------------
  lisa <- localmoran(map_ok$ET, lw, zero.policy = TRUE)
  
  # Guardar resultados (por posición, robusto)
  map_ok$Ii      <- lisa[, 1]
  map_ok$Z_Ii    <- lisa[, 4]
  map_ok$p_value <- lisa[, 5]
  
  # Clusters (α=0.05)
  alpha <- 0.05
  map_ok$ET_z  <- ET_z
  map_ok$WET_z <- ET_lag
  
  map_ok <- map_ok %>%
    mutate(
      sig = p_value < alpha,
      cluster = case_when(
        sig & ET_z >= 0 & WET_z >= 0 ~ "Alta-Alta (HH)",
        sig & ET_z <  0 & WET_z <  0 ~ "Baja-Baja (LL)",
        sig & ET_z >= 0 & WET_z <  0 ~ "Alta-Baja (HL)",
        sig & ET_z <  0 & WET_z >= 0 ~ "Baja-Alta (LH)",
        TRUE                         ~ "No significativo"
      )
    )
  
  # Resumen LISA por año (conteos)
  lisa_counts <- as.data.frame(table(map_ok$cluster))
  names(lisa_counts) <- c("cluster","n")
  lisa_counts$Año <- y
  lisa_resumen_tab[[as.character(y)]] <- lisa_counts
  
  # Guardar LISA detallado (CSV sin geometría)
  write.csv(
    map_ok %>% st_drop_geometry() %>% select(Region, ET, Ii, Z_Ii, p_value, cluster),
    file.path(out_dir, "LISA_CSV", paste0("LISA_DETALLE_ET_", y, ".csv")),
    row.names = FALSE
  )
  
  #---------------------------------------------------------
  # 5.D) MAPAS (ET y LISA) + GUARDADO
  #---------------------------------------------------------
  # Mapa ET
  tm_ET <- tm_shape(map_ok) +
    tm_polygons("ET", title = paste0("ET (", y, ")"), palette = "viridis", colorNA = "white") +
    tm_borders() +
    tm_layout(
      main.title = paste0("Eficiencia Técnica (ET) - Año ", y),
      legend.outside = TRUE,
      frame = FALSE
    )
  
  tmap_save(
    tm_ET,
    filename = file.path(out_dir, "MAPAS_ET", paste0("MAPA_ET_", y, ".png")),
    width = 1800, height = 1200
  )
  
  # Mapa LISA clusters
  tm_LISA <- tm_shape(map_ok) +
    tm_polygons("cluster", title = paste0("Clusters LISA (α=0.05) - ", y), colorNA = "white") +
    tm_borders() +
    tm_layout(
      main.title = paste0("Clusters espaciales ET (LISA) - Año ", y),
      legend.outside = TRUE,
      frame = FALSE
    )
  
  tmap_save(
    tm_LISA,
    filename = file.path(out_dir, "MAPAS_LISA", paste0("MAPA_LISA_ET_", y, ".png")),
    width = 1800, height = 1200
  )
}

#-----------------------------------------------------------
# 6) EXPORTAR TABLAS FINALES (Moran anual + Resumen LISA)
#-----------------------------------------------------------
moran_year_df <- bind_rows(moran_tab)
lisa_resumen_df <- bind_rows(lisa_resumen_tab) %>% select(Año, cluster, n)

# Guardar CSV
write.csv(moran_year_df, file.path(out_dir, "TABLAS", "MORAN_GLOBAL_POR_ANIO.csv"), row.names = FALSE)
write.csv(lisa_resumen_df, file.path(out_dir, "TABLAS", "RESUMEN_LISA_POR_ANIO.csv"), row.names = FALSE)

# Guardar Excel (una sola salida ordenada)
write_xlsx(
  list(
    Moran_global_por_anio = moran_year_df,
    Resumen_LISA_por_anio = lisa_resumen_df
  ),
  path = file.path(out_dir, "TABLAS", "RESULTADOS_ESPACIALES_POR_ANIO.xlsx")
)

cat("\n\nLISTO ✅\n")
cat("Carpeta de salida:\n", out_dir, "\n")
cat("Archivos clave:\n",
    "- TABLAS/RESULTADOS_ESPACIALES_POR_ANIO.xlsx\n",
    "- TABLAS/MORAN_GLOBAL_POR_ANIO.csv\n",
    "- TABLAS/RESUMEN_LISA_POR_ANIO.csv\n",
    "- SCATTER/SCATTER_MORAN_ET_YYYY.png\n",
    "- MAPAS_ET/MAPA_ET_YYYY.png\n",
    "- MAPAS_LISA/MAPA_LISA_ET_YYYY.png\n",
    "- LISA_CSV/LISA_DETALLE_ET_YYYY.csv\n")
############################################################
# FIN
############################################################