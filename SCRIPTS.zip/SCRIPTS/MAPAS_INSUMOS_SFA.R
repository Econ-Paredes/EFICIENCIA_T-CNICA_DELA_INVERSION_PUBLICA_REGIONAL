############################################################
# SCRIPT COMPLETO: UNIR BASE SFA + MAPA Y GENERAR MAPA (R)
############################################################

# 0) CONFIGURACION INICIAL
rm(list = ls())

setwd("D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA")
getwd()

# Paquetes (instalar solo la primera vez)
# install.packages(c("sf","dplyr","readxl","ggplot2","viridis","writexl","stringi","stringr"))

library(sf)
library(dplyr)
library(readxl)
library(ggplot2)
library(viridis)
library(writexl)
library(stringi)
library(stringr)

############################################################
# 1) CARGAR MAPA (GeoJSON)
############################################################
map_file <- "peru_departamental_simple.json"
peru_dep <- st_read(map_file, quiet = FALSE)

# Ajustar nombre de columna si corresponde (por defecto NOMBDEP)
peru_dep <- peru_dep %>%
  mutate(
    Region = toupper(trimws(NOMBDEP))  # clave de union
  )

############################################################
# 2) CARGAR BASE SFA (Excel) Y ESTANDARIZAR REGION (SIN TILDES)
############################################################
base_sfa <- read_excel("BASE_SFA_FINAL.xlsx")

base_sfa <- base_sfa %>%
  mutate(
    Region = stri_trans_general(Region, "Latin-ASCII"),
    Region = toupper(trimws(Region))
  ) %>%
  mutate(
    Region = case_when(
      Region == "AMAZONAS" ~ "AMAZONAS",
      Region == "ANCASH" ~ "ANCASH",
      Region == "APURIMAC" ~ "APURIMAC",
      Region == "AREQUIPA" ~ "AREQUIPA",
      Region == "AYACUCHO" ~ "AYACUCHO",
      Region == "CAJAMARCA" ~ "CAJAMARCA",
      Region == "CALLAO" ~ "CALLAO",
      Region %in% c("CUSCO", "CUZCO") ~ "CUSCO",
      Region == "HUANCAVELICA" ~ "HUANCAVELICA",
      Region == "HUANUCO" ~ "HUANUCO",
      Region == "ICA" ~ "ICA",
      Region == "JUNIN" ~ "JUNIN",
      Region %in% c("LA LIBERTAD", "LIBERTAD") ~ "LA LIBERTAD",
      Region == "LAMBAYEQUE" ~ "LAMBAYEQUE",
      Region %in% c("LIMA", "LIMA METROPOLITANA") ~ "LIMA",
      Region == "LORETO" ~ "LORETO",
      Region == "MADRE DE DIOS" ~ "MADRE DE DIOS",
      Region == "MOQUEGUA" ~ "MOQUEGUA",
      Region == "PASCO" ~ "PASCO",
      Region == "PIURA" ~ "PIURA",
      Region == "PUNO" ~ "PUNO",
      Region == "SAN MARTIN" ~ "SAN MARTIN",
      Region == "TACNA" ~ "TACNA",
      Region == "TUMBES" ~ "TUMBES",
      Region == "UCAYALI" ~ "UCAYALI",
      TRUE ~ Region
    )
  )

# Exportar base limpia (opcional)
write_xlsx(base_sfa, "BASE_SFA_FINAL_REGION_OK.xlsx")

############################################################
# 3) RESUMIR BASE PANEL PARA MAPAS (PROMEDIOS 2015-2024)
############################################################
sfa_map <- base_sfa %>%
  group_by(Region) %>%
  summarise(
    TE_prom      = mean(TE_IRIPR, na.rm = TRUE),
    NPROJ_prom   = mean(NPROJ, na.rm = TRUE),
    DUR_prom     = mean(DUR, na.rm = TRUE),
    IEPperc_prom = mean(IEPperc, na.rm = TRUE),
    IRIPR_prom   = mean(IRIPR, na.rm = TRUE)
  )

############################################################
# 4) UNIR MAPA + SFA (LEFT JOIN)
############################################################
mapa_final <- peru_dep %>%
  left_join(sfa_map, by = "Region")

############################################################
# 5) VERIFICAR UNION (REGIONES SIN MATCH)
############################################################
no_match <- mapa_final %>%
  st_drop_geometry() %>%
  filter(is.na(TE_prom)) %>%
  select(Region)

print(no_match)  # si aparece vacío, unión OK

############################################################
# 6) MAPA COROPLETICO: EFICIENCIA TECNICA PROMEDIO (TE_prom)
############################################################
p_te <- ggplot(mapa_final) +
  geom_sf(aes(fill = TE_prom), color = "white", linewidth = 0.2) +
  scale_fill_viridis(
    name = "Eficiencia tecnica\npromedio",
    option = "C",
    na.value = "grey90"
  ) +
  labs(
    title = "Eficiencia tecnica promedio de los proyectos de inversion publica",
    subtitle = "Promedio regional 2015-2024"
  ) +
  theme_minimal()

print(p_te)

############################################################
# 7) GUARDAR MAPA (CALIDAD TESIS)
############################################################
ggsave(
  filename = "Mapa_Eficiencia_Tecnica_Promedio.png",
  plot = p_te,
  width = 10,
  height = 8,
  dpi = 300
)

############################################################
# FIN
############################################################

############################################################
############################################################
# MAPA ULTRA HD: PROYECTOS CULMINADOS (%) 2015–2024
# + Etiquetas completas + Leyenda corregida
# + Ajuste manual de etiqueta CALLAO (para que no se cruce con LIMA)
############################################################

# Limpiar (opcional)
# rm(list = ls())

# Paquetes
library(sf)
library(dplyr)
library(ggplot2)
library(scales)

# ----------------------------------------------------------
# 0) SUPUESTOS: ya tienes cargados en memoria:
#   - base_sfa  (data.frame con Region y PC)
#   - peru_dep  (sf con geometría y columna Region para el join)
# Si tu mapa usa NOMBDEP, crea Region antes (ver nota al final).
# ----------------------------------------------------------

# 1) Promedio regional de PC
pc_map <- base_sfa %>%
  group_by(Region) %>%
  summarise(PC_prom = mean(PC, na.rm = TRUE), .groups = "drop")

# ⚠️ Si PC está en 0–100 (porcentaje), activa esta línea:
# pc_map <- pc_map %>% mutate(PC_prom = PC_prom / 100)

# 2) Unir con mapa (requiere que peru_dep tenga columna Region)
mapa_pc <- peru_dep %>%
  left_join(pc_map, by = "Region")

# 3) Centroides seguros para etiquetas + texto
labels_pc <- mapa_pc %>%
  st_point_on_surface() %>%
  mutate(
    x = st_coordinates(.)[, 1],
    y = st_coordinates(.)[, 2],
    etiqueta = paste0(Region, "\n", percent(PC_prom, accuracy = 0.1)),
    Region_fix = toupper(trimws(Region))
  ) %>%
  st_drop_geometry()

# 4) Ajuste manual SOLO para CALLAO (mover etiqueta)
#    (ajusta los valores si lo quieres más lejos/cerca)
labels_pc <- labels_pc %>%
  mutate(
    x = ifelse(grepl("CALLAO", Region_fix), x - 0.45, x),
    y = ifelse(grepl("CALLAO", Region_fix), y + 0.35, y)
  )

# 5) Rango de escala
pc_lim <- range(pc_map$PC_prom, na.rm = TRUE)

# 6) Mapa
map_pc <- ggplot(mapa_pc) +
  geom_sf(aes(fill = PC_prom), color = "white", linewidth = 0.25) +
  geom_text(
    data = labels_pc,
    aes(x = x, y = y, label = etiqueta),
    size = 2.6,
    lineheight = 0.95,
    color = "black"
  ) +
  scale_fill_gradient(
    name = "Proyectos culminados (%)",
    low  = "#deebf7",
    high = "#08306b",
    limits = pc_lim,
    labels = percent_format(accuracy = 1),
    na.value = "grey90"
  ) +
  labs(
    title = "Porcentaje promedio de proyectos culminados",
    subtitle = "Promedio regional anual, 2015–2024"
  ) +
  theme_void(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    plot.subtitle = element_text(size = 12),
    legend.position = "right",
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10),
    plot.margin = margin(10, 10, 10, 10)
  )

print(map_pc)

# 7) Guardar ULTRA HD (sin distorsión)
ggsave(
  filename = "Mapa_PC_Proyectos_Culminados_ULTRA_HD.png",
  plot = map_pc,
  device = "png",
  width = 14,
  height = 9,
  units = "in",
  dpi = 600,
  bg = "white"
)

############################################################
# MAPA ULTRA HD: TASA DE EJECUCIÓN DE INVERSIÓN (TEI) 2015–2024
# Alta nitidez + etiquetas completas + leyenda
# + Ajuste manual de etiqueta CALLAO (para que no se cruce con LIMA)
############################################################

library(sf)
library(dplyr)
library(ggplot2)
library(scales)

# 1) Promedio regional de TEI
tei_map <- base_sfa %>%
  group_by(Region) %>%
  summarise(TEI_prom = mean(TEI, na.rm = TRUE), .groups = "drop")

# ⚠️ Si TEI está en 0–100 (porcentaje), activa esta línea:
# tei_map <- tei_map %>% mutate(TEI_prom = TEI_prom / 100)

# 2) Unir con mapa
mapa_tei <- peru_dep %>%
  left_join(tei_map, by = "Region")

# 3) Puntos internos para etiquetas + texto
labels_tei <- mapa_tei %>%
  st_point_on_surface() %>%
  mutate(
    x = st_coordinates(.)[, 1],
    y = st_coordinates(.)[, 2],
    etiqueta = paste0(Region, "\n", percent(TEI_prom, accuracy = 0.1)),
    Region_fix = toupper(trimws(Region))
  ) %>%
  st_drop_geometry()

# 4) Ajuste manual SOLO para CALLAO (mover etiqueta)
labels_tei <- labels_tei %>%
  mutate(
    x = ifelse(grepl("CALLAO", Region_fix), x - 0.45, x),
    y = ifelse(grepl("CALLAO", Region_fix), y + 0.35, y)
  )

# 5) Rango de escala
tei_lim <- range(tei_map$TEI_prom, na.rm = TRUE)

# 6) Mapa
map_tei <- ggplot(mapa_tei) +
  geom_sf(aes(fill = TEI_prom), color = "white", linewidth = 0.25) +
  geom_text(
    data = labels_tei,
    aes(x = x, y = y, label = etiqueta),
    size = 2.6,
    lineheight = 0.95,
    color = "black"
  ) +
  scale_fill_gradient(
    name = "Ejecución de inversión (TEI, %)",
    low  = "#deebf7",
    high = "#08306b",
    limits = tei_lim,
    labels = percent_format(accuracy = 1),
    na.value = "grey90"
  ) +
  labs(
    title = "Tasa promedio de ejecución de la inversión pública (TEI)",
    subtitle = "Promedio regional anual, 2015–2024"
  ) +
  theme_void(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    plot.subtitle = element_text(size = 12),
    legend.position = "right",
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10),
    plot.margin = margin(10, 10, 10, 10)
  )

print(map_tei)

# 7) Guardar ULTRA HD
ggsave(
  filename = "Mapa_TEI_Ejecucion_Inversion_ULTRA_HD.png",
  plot = map_tei,
  device = "png",
  width = 14,
  height = 9,
  units = "in",
  dpi = 600,
  bg = "white"
)

############################################################
# TABLA DE MEDIAS REGIONALES
############################################################

library(dplyr)
library(writexl)

# Calcular media por región
tabla_media_region <- base_sfa %>%
  select(Region, TEI, PC, IRIPR, NPROJ, DUR, IEPperc) %>%
  group_by(Region) %>%
  summarise(
    TEI     = mean(TEI, na.rm = TRUE),
    PC      = mean(PC, na.rm = TRUE),
    IRIPR   = mean(IRIPR, na.rm = TRUE),
    NPROJ   = mean(NPROJ, na.rm = TRUE),
    DUR     = mean(DUR, na.rm = TRUE),
    IEPperc = mean(IEPperc, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(IRIPR))   # opcional: ordenar por desempeño

# Ver tabla en consola
print(tabla_media_region)

############################################################
# Exportar a Excel
############################################################
write_xlsx(
  tabla_media_region,
  "Tabla_medias_regionales_variables_estudio.xlsx"
)

############################################################
# MAPAS ULTRA HD (NPROJ, DUR, IEPperc) + etiquetas separadas
# CALLAO y LIMA (desplazamiento manual)
############################################################

library(sf)
library(dplyr)
library(ggplot2)
library(scales)

#----------------------------------------------------------
# SUPUESTOS:
# - base_sfa ya cargada (tiene: Region, NPROJ, DUR, IEPperc)
# - peru_dep ya cargada como sf (tiene columna Region)
#----------------------------------------------------------

# ====== FUNCIÓN GENERAL PARA CREAR MAPA (PROMEDIO 2015–2024) ======
map_promedio_region <- function(data, mapa_sf, varname,
                                titulo, subtitulo,
                                leyenda, archivo_salida,
                                paleta_low = "#deebf7",
                                paleta_high = "#08306b",
                                etiqueta_formato = c("numero", "dinero", "porcentaje"),
                                shift_callao = c(-0.45, 0.35),
                                shift_lima   = c( 0.12,-0.10),
                                dpi_out = 600) {
  
  etiqueta_formato <- match.arg(etiqueta_formato)
  
  # 1) promedio regional
  prom <- data %>%
    group_by(Region) %>%
    summarise(valor = mean(.data[[varname]], na.rm = TRUE), .groups = "drop")
  
  # 2) join
  mapa_var <- mapa_sf %>% left_join(prom, by = "Region")
  
  # 3) centroides/etiquetas
  labels <- mapa_var %>%
    st_point_on_surface() %>%
    mutate(
      x = st_coordinates(.)[,1],
      y = st_coordinates(.)[,2],
      Region_fix = toupper(trimws(Region))
    ) %>%
    st_drop_geometry()
  
  # Formato de etiqueta
  if (etiqueta_formato == "porcentaje") {
    labels <- labels %>%
      mutate(etiqueta = paste0(Region, "\n", percent(valor, accuracy = 0.1)))
    lab_fun <- percent_format(accuracy = 1)
  } else if (etiqueta_formato == "dinero") {
    labels <- labels %>%
      mutate(etiqueta = paste0(Region, "\nS/ ", comma(valor, accuracy = 1)))
    lab_fun <- label_comma(accuracy = 1)
  } else { # numero
    labels <- labels %>%
      mutate(etiqueta = paste0(Region, "\n", comma(valor, accuracy = 0.1)))
    lab_fun <- label_comma(accuracy = 0.1)
  }
  
  # 4) Desplazar etiquetas CALLAO y LIMA (para separarlas)
  labels <- labels %>%
    mutate(
      x = case_when(
        grepl("CALLAO", Region_fix) ~ x + shift_callao[1],
        grepl("^LIMA$", Region_fix) ~ x + shift_lima[1],
        TRUE ~ x
      ),
      y = case_when(
        grepl("CALLAO", Region_fix) ~ y + shift_callao[2],
        grepl("^LIMA$", Region_fix) ~ y + shift_lima[2],
        TRUE ~ y
      )
    )
  
  # 5) rango escala
  lim <- range(prom$valor, na.rm = TRUE)
  
  # 6) plot
  p <- ggplot(mapa_var) +
    geom_sf(aes(fill = valor), color = "white", linewidth = 0.25) +
    geom_text(
      data = labels,
      aes(x = x, y = y, label = etiqueta),
      size = 2.6,
      lineheight = 0.95,
      color = "black"
    ) +
    scale_fill_gradient(
      name = leyenda,
      low  = paleta_low,
      high = paleta_high,
      limits = lim,
      labels = lab_fun,
      na.value = "grey90"
    ) +
    labs(title = titulo, subtitle = subtitulo) +
    theme_void(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      plot.subtitle = element_text(size = 12),
      legend.position = "right",
      legend.title = element_text(size = 11),
      legend.text = element_text(size = 10),
      plot.margin = margin(10, 10, 10, 10)
    )
  
  print(p)
  
  ggsave(
    filename = archivo_salida,
    plot = p,
    device = "png",
    width = 14,
    height = 9,
    units = "in",
    dpi = dpi_out,
    bg = "white"
  )
  
  return(invisible(p))
}

############################################################
# 1) MAPA NPROJ (número promedio de proyectos concluidos)
############################################################
map_promedio_region(
  data = base_sfa,
  mapa_sf = peru_dep,
  varname = "NPROJ",
  titulo = "Número promedio de proyectos concluidos (NPROJ)",
  subtitulo = "Promedio regional anual, 2015–2024",
  leyenda = "Proyectos concluidos (N°)",
  archivo_salida = "Mapa_NPROJ_ULTRA_HD.png",
  etiqueta_formato = "numero",
  shift_callao = c(-0.55, 0.40),  # más separación
  shift_lima   = c( 0.12,-0.12)
)

############################################################
# 2) MAPA DUR (duración promedio en meses)
############################################################
map_promedio_region(
  data = base_sfa,
  mapa_sf = peru_dep,
  varname = "DUR",
  titulo = "Duración promedio de ejecución de proyectos (DUR)",
  subtitulo = "Promedio regional anual, 2015–2024",
  leyenda = "Duración (meses)",
  archivo_salida = "Mapa_DUR_ULTRA_HD.png",
  etiqueta_formato = "numero",
  shift_callao = c(-0.55, 0.40),
  shift_lima   = c( 0.12,-0.12)
)

############################################################
# 3) MAPA IEPperc (inversión pública per cápita)
############################################################
map_promedio_region(
  data = base_sfa,
  mapa_sf = peru_dep,
  varname = "IEPperc",
  titulo = "Inversión pública per cápita (IEPperc)",
  subtitulo = "Promedio regional anual, 2015–2024",
  leyenda = "Inversión per cápita (S/)",
  archivo_salida = "Mapa_IEPperc_ULTRA_HD.png",
  etiqueta_formato = "dinero",
  shift_callao = c(-0.55, 0.40),
  shift_lima   = c( 0.12,-0.12)
)

############################################################
# MAPAS ULTRA HD (con etiquetas) PARA: ET, IE, CIN, CV, DP
# - ET viene de BASE_SFA_FINAL_REGION_OK.xlsx (TE_IRIPR -> ET)
# - IE, CIN, CV, DP vienen de DATA_PANEL.xlsx
# - Une todo por Region y genera mapas con ajuste CALLAO y LIMA
############################################################

rm(list = ls())

library(sf)
library(dplyr)
library(readxl)
library(ggplot2)
library(scales)
library(stringi)

############################################################
# 0) RUTA DE TRABAJO (AJUSTA SI CAMBIÓ)
############################################################
setwd("D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA")

############################################################
# 1) CARGAR MAPA (JSON) Y PREPARAR COLUMNA Region
############################################################
map_file <- "peru_departamental_simple.json"
peru_dep <- st_read(map_file, quiet = FALSE)

# Si tu mapa tiene NOMBDEP, crea Region
# (si ya existe Region, esta línea solo la sobreescribe bien)
peru_dep <- peru_dep %>%
  mutate(
    Region = toupper(trimws(NOMBDEP)),
    Region = stri_trans_general(Region, "Latin-ASCII")
  )

############################################################
# 2) CARGAR BASE SFA (ET) Y RENOMBRAR TE_IRIPR -> ET
############################################################
base_sfa <- read_excel("BASE_SFA_FINAL_REGION_OK.xlsx") %>%
  mutate(
    Region = stri_trans_general(Region, "Latin-ASCII"),
    Region = toupper(trimws(Region))
  ) %>%
  rename(ET = TE_IRIPR)

# (opcional) verificar
# names(base_sfa)

############################################################
# 3) CARGAR BASE PANEL (IE, CIN, CV, DP) Y NORMALIZAR Region
############################################################
data_panel <- read_excel("DATA_PANEL.xlsx") %>%
  mutate(
    Region = stri_trans_general(Region, "Latin-ASCII"),
    Region = toupper(trimws(Region))
  )

# IMPORTANTE: asegúrate de que estas columnas existan en DATA_PANEL.xlsx:
# IE, CIN, CV, DP  (DP = Densidad Poblacional)
# Si tienen otro nombre, cámbialas aquí:
# data_panel <- data_panel %>% rename(IE = <otro>, CIN = <otro>, CV = <otro>, DP = <otro>)

############################################################
# 4) UNIR BASES (POR Region y Año si aplica)
# - Para mapas promedio 2015–2024 basta unir por Region+Año si existe Año
############################################################

# Detectar si ambas tienen Año
tiene_anio_sfa   <- "Año" %in% names(base_sfa)
tiene_anio_panel <- "Año" %in% names(data_panel)

if (tiene_anio_sfa && tiene_anio_panel) {
  base_full <- base_sfa %>%
    left_join(data_panel, by = c("Region", "Año"))
} else {
  # Si DATA_PANEL no tiene Año (o SFA no tiene Año), unir solo por Region
  base_full <- base_sfa %>%
    left_join(data_panel, by = "Region")
}

# Verifica que existan las variables finales
# names(base_full)

############################################################
# 5) TABLA RESUMEN (PROMEDIO REGIONAL 2015–2024) PARA DETERMINANTES
############################################################
tabla_medias_determinantes <- base_full %>%
  group_by(Region) %>%
  summarise(
    ET  = mean(ET,  na.rm = TRUE),
    IE  = mean(IE,  na.rm = TRUE),
    CIN = mean(CIN, na.rm = TRUE),
    CV  = mean(CV,  na.rm = TRUE),
    DP  = mean(DP,  na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(ET))

print(tabla_medias_determinantes)

############################################################
# 6) FUNCIÓN PARA MAPA PROMEDIO ULTRA HD CON ETIQUETAS
############################################################
mapa_promedio <- function(var, titulo, archivo_png,
                          etiqueta_fmt = c("percent","number","comma"),
                          shift_callao = TRUE, shift_lima = TRUE,
                          low_col = "#deebf7", high_col = "#08306b") {
  
  etiqueta_fmt <- match.arg(etiqueta_fmt)
  
  # Promedio por región del indicador
  df_var <- base_full %>%
    group_by(Region) %>%
    summarise(valor = mean(.data[[var]], na.rm = TRUE), .groups = "drop")
  
  # Unir al mapa
  mapa <- peru_dep %>%
    left_join(df_var, by = "Region")
  
  # Puntos para etiquetas
  labels <- mapa %>%
    st_point_on_surface() %>%
    mutate(
      x = st_coordinates(.)[,1],
      y = st_coordinates(.)[,2],
      Region_fix = toupper(trimws(Region))
    ) %>%
    st_drop_geometry()
  
  # Texto etiqueta (valor)
  if (etiqueta_fmt == "percent") {
    labels <- labels %>% mutate(valor_lbl = percent(valor, accuracy = 0.1))
    lab_fun <- percent_format(accuracy = 1)
  } else if (etiqueta_fmt == "comma") {
    labels <- labels %>% mutate(valor_lbl = comma(valor, accuracy = 0.1))
    lab_fun <- comma_format(accuracy = 0.1)
  } else {
    labels <- labels %>% mutate(valor_lbl = format(round(valor, 3), nsmall = 3))
    lab_fun <- label_number(accuracy = 0.01)
  }
  
  labels <- labels %>%
    mutate(etiqueta = paste0(Region, "\n", valor_lbl))
  
  # Ajuste manual (CALLAO y LIMA)
  if (shift_callao) {
    labels <- labels %>%
      mutate(
        x = ifelse(grepl("CALLAO", Region_fix), x - 0.45, x),
        y = ifelse(grepl("CALLAO", Region_fix), y + 0.35, y)
      )
  }
  if (shift_lima) {
    labels <- labels %>%
      mutate(
        x = ifelse(Region_fix == "LIMA", x + 0.10, x),
        y = ifelse(Region_fix == "LIMA", y - 0.10, y)
      )
  }
  
  # Rango escala
  lims <- range(df_var$valor, na.rm = TRUE)
  
  # Mapa
  p <- ggplot(mapa) +
    geom_sf(aes(fill = valor), color = "white", linewidth = 0.25) +
    geom_text(
      data = labels,
      aes(x = x, y = y, label = etiqueta),
      size = 2.6, lineheight = 0.95, color = "black"
    ) +
    scale_fill_gradient(
      name = titulo,
      low = low_col, high = high_col,
      limits = lims,
      labels = lab_fun,
      na.value = "grey90"
    ) +
    labs(
      title = titulo,
      subtitle = "Promedio regional anual, 2015–2024"
    ) +
    theme_void(base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 16),
      plot.subtitle = element_text(size = 12),
      legend.position = "right",
      legend.title = element_text(size = 11),
      legend.text = element_text(size = 10),
      plot.margin = margin(10, 10, 10, 10)
    )
  
  print(p)
  
  ggsave(
    filename = archivo_png,
    plot = p,
    device = "png",
    width = 14, height = 9, units = "in",
    dpi = 600,
    bg = "white"
  )
}

############################################################
# 7) EJECUTAR MAPAS (PROMEDIO 2015–2024)
############################################################

# ET (0-1) -> formato numérico
mapa_promedio("ET",  "Eficiencia técnica (ET)", "Mapa_ET_ULTRA_HD.png",
              etiqueta_fmt = "number", shift_callao = TRUE, shift_lima = TRUE)

# IE (monto) -> formato con separador de miles
mapa_promedio("IE",  "Inversión ejecutada (IE)", "Mapa_IE_ULTRA_HD.png",
              etiqueta_fmt = "comma", shift_callao = TRUE, shift_lima = TRUE)

# CIN (índice) -> numérico (ajusta si está en %)
mapa_promedio("CIN", "Confianza institucional (CIN)", "Mapa_CIN_ULTRA_HD.png",
              etiqueta_fmt = "number", shift_callao = TRUE, shift_lima = TRUE)

# CV (km o índice) -> comma si son km, number si es índice
mapa_promedio("CV",  "Conectividad vial (CV)", "Mapa_CV_ULTRA_HD.png",
              etiqueta_fmt = "comma", shift_callao = TRUE, shift_lima = TRUE)

# DP (hab/km2) -> comma
mapa_promedio("DP",  "Densidad poblacional (DP)", "Mapa_DP_ULTRA_HD.png",
              etiqueta_fmt = "comma", shift_callao = TRUE, shift_lima = TRUE)

############################################################
# MAPA ULTRA HD: DENSIDAD POBLACIONAL (DP) 2015–2024
# - Corrige "mapa blanco" usando escala log10 (Callao outlier)
# - Etiquetas + separación Callao/Lima
############################################################

rm(list = ls())

# 0) Carpeta de trabajo
setwd("D:/MIGUEL PAREDES  M.2/Desktop/MIGUEL PAREDES/MAESTRIA TITULACIÓN/ESTIMACIONES/ESTIMACIÓN_SFA")

# 1) Paquetes
# install.packages(c("sf","dplyr","readxl","ggplot2","scales","stringi","writexl"))
library(sf)
library(dplyr)
library(readxl)
library(ggplot2)
library(scales)
library(stringi)
library(writexl)

############################################################
# 2) Cargar MAPA
############################################################
map_file <- "peru_departamental_simple.json"
peru_dep <- st_read(map_file, quiet = FALSE)

# Ajusta aquí si el nombre de la columna de departamento es distinta
# (en tu caso venías usando NOMBDEP)
peru_dep <- peru_dep %>%
  mutate(
    Region = toupper(trimws(NOMBDEP)),
    Region = stri_trans_general(Region, "Latin-ASCII")
  )

############################################################
# 3) Cargar BASE SFA (para ET) y renombrar TE_IRIPR -> ET
############################################################
base_sfa <- read_excel("BASE_SFA_FINAL_REGION_OK.xlsx") %>%
  mutate(
    Region = stri_trans_general(Region, "Latin-ASCII"),
    Region = toupper(trimws(Region))
  ) %>%
  rename(ET = TE_IRIPR)

############################################################
# 4) Cargar DATA_PANEL (IE, CIN, CV, DP, etc.)
############################################################
panel <- read_excel("DATA_PANEL.xlsx") %>%
  mutate(
    Region = stri_trans_general(Region, "Latin-ASCII"),
    Region = toupper(trimws(Region))
  )

############################################################
# 5) Unir bases (panel + ET). Si comparten columnas repetidas,
#    puedes quedarte con las que necesites.
############################################################
data_final <- panel %>%
  left_join(base_sfa %>% select(Region, Año, ET), by = c("Region","Año"))

############################################################
# 6) Promedio regional 2015–2024 de DP
############################################################
dp_map <- data_final %>%
  group_by(Region) %>%
  summarise(
    DP_prom = mean(DP, na.rm = TRUE),
    .groups = "drop"
  )

# Unir con mapa
mapa_dp <- peru_dep %>%
  left_join(dp_map, by = "Region")

############################################################
# 7) Etiquetas (centroides) + mover CALLAO para que no choque con LIMA
############################################################
labels_dp <- mapa_dp %>%
  st_point_on_surface() %>%
  mutate(
    x = st_coordinates(.)[,1],
    y = st_coordinates(.)[,2],
    # separa Callao un poco hacia el O y hacia abajo
    x = ifelse(Region == "CALLAO", x - 0.35, x),
    y = ifelse(Region == "CALLAO", y - 0.25, y),
    etiqueta = paste0(Region, "\n", round(DP_prom, 1))
  ) %>%
  st_drop_geometry()

############################################################
# 8) MAPA (escala log10 para evitar “todo blanco”)
############################################################
map_dp <- ggplot(mapa_dp) +
  geom_sf(aes(fill = DP_prom), color = "white", linewidth = 0.25) +
  geom_text(
    data = labels_dp,
    aes(x = x, y = y, label = etiqueta),
    size = 2.6, lineheight = 0.95, color = "black"
  ) +
  scale_fill_gradient(
    name = "Densidad poblacional (hab/km²)",
    low  = "#deebf7",
    high = "#08306b",
    trans = "log10",              # <- clave para que no se “aplane” la escala
    labels = label_comma(),
    na.value = "grey90"
  ) +
  labs(
    title = "Densidad poblacional (DP)",
    subtitle = "Promedio regional anual, 2015–2024"
  ) +
  theme_void(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold", size = 16),
    plot.subtitle = element_text(size = 12),
    legend.position = "right",
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10),
    plot.margin = margin(10, 10, 10, 10)
  )

print(map_dp)

############################################################
# 9) Guardar ULTRA HD
############################################################
ggsave(
  filename = "Mapa_DP_ULTRA_HD.png",
  plot = map_dp,
  device = "png",
  width = 14, height = 9, units = "in",
  dpi = 600, bg = "white"
)




